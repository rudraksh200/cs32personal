// minimal Hello World! program for testing Makefiles

#include <iostream>

int main() {
  std::cout << "Hello, World!" << std::endl;
  return 0;
}
